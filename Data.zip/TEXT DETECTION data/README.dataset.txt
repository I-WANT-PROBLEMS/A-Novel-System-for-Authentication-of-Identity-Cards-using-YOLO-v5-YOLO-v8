# ID Text Detection > 2023-05-22 7:22pm
https://universe.roboflow.com/dl-project-annotations/id-text-detection

Provided by a Roboflow user
License: CC BY 4.0

